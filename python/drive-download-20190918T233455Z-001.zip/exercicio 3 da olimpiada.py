N = int(input('N:'))

conta = (N*6)-8
print(conta)
