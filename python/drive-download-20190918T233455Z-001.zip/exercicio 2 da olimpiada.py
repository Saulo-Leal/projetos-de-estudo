#m = mae
#A = primeiro filho
#B = segundo filho
#idade = filho mais velho


M = int(input('M:'))
A = int(input('A:'))
B = int(input('B:'))

idade = M-(A+B)

print(idade)


    
